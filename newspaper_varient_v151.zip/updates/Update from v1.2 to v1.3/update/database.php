<?php
session_start();
error_reporting(0);

require_once('includes/Bcrypt.php');

$cls = new Bcrypt();

if (!$cls->check_password($_SESSION["purchase_code"], $_SESSION["code"])) {
    $_SESSION["error"] = "Invalid purchase code!";
    header("Location: index.php");
    exit();
}

if (isset($_POST["btn_update"])) {

    $_SESSION["db_host"] = $_POST['db_host'];
    $_SESSION["db_name"] = $_POST['db_name'];
    $_SESSION["db_user"] = $_POST['db_user'];
    $_SESSION["db_password"] = $_POST['db_password'];

    /* Database Credentials */
    defined("DB_HOST") ? null : define("DB_HOST", $_POST['db_host']);
    defined("DB_USER") ? null : define("DB_USER", $_POST['db_user']);
    defined("DB_PASS") ? null : define("DB_PASS", $_POST['db_password']);
    defined("DB_NAME") ? null : define("DB_NAME", $_POST['db_name']);

    /* Connect */
    $connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if (!$connection) {
        $_SESSION["error"] = "Connect failed! Please check your database credentials.";
        header("Location: database.php");
        exit();
    }

    $connection->query("SET CHARACTER SET utf8");
    $connection->query("SET NAMES utf8");


    $sql = "CREATE TABLE `ad_spaces` (
            `id` int(11) AUTO_INCREMENT PRIMARY KEY, 
            `ad_space` Text,
            `ad_code_728` Text,
            `ad_code_468` Text,
            `ad_code_300` Text,
            `ad_code_234` Text
            )";

    $sql_1 = "CREATE TABLE `audios` (
            `id` int(11) AUTO_INCREMENT PRIMARY KEY, 
            `post_id` INT,
            `audio_path` VARCHAR(255),
            `audio_name` VARCHAR(500),
            `musician` VARCHAR(500),
            `download_button` INT DEFAULT 1
            )";

    $sql_2 = "CREATE TABLE `rss_feeds` (
            `id` int(11) AUTO_INCREMENT PRIMARY KEY, 
            `feed_name` VARCHAR(500),
            `feed_url` VARCHAR(1000),
            `post_limit` INT,
            `category_id` INT,
            `subcategory_id` INT,
            `image_big` VARCHAR(250),
            `image_default` VARCHAR(250),
            `image_slider` VARCHAR(250),
            `image_mid` VARCHAR(250),
            `image_small` VARCHAR(250),
            `auto_update` INT DEFAULT 1,
            `read_more_button` INT DEFAULT 1,
            `read_more_button_text` VARCHAR(255) DEFAULT 'Read More',
            `user_id` INT,
            `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";


    /* update database */
    mysqli_query($connection, "DROP TABLE ads;");
    mysqli_query($connection, $sql);
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('index_top', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('index_bottom', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('post_top', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('post_bottom', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('category_top', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('category_bottom', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('tag_top', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('tag_bottom', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('search_top', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('search_bottom', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('profile_top', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('profile_bottom', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('reading_list_top', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('reading_list_bottom', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('sidebar_top', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('sidebar_bottom', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('header', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('posts_top', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, "INSERT INTO ad_spaces (`ad_space`, `ad_code_728`, `ad_code_468`, `ad_code_300`, `ad_code_234`) VALUES ('posts_bottom', NULL, NULL, NULL,NULL);");
    mysqli_query($connection, $sql_1);
    mysqli_query($connection, "ALTER TABLE pages ADD COLUMN `link` VARCHAR(1000);");
    mysqli_query($connection, "ALTER TABLE pages ADD COLUMN `parent_id` INT DEFAULT 0;");
    mysqli_query($connection, "ALTER TABLE pages ADD COLUMN `page_type` VARCHAR(50);");
    mysqli_query($connection, "UPDATE pages SET slug='profile-update' WHERE slug='update-profile';");
    mysqli_query($connection, "ALTER TABLE polls ADD COLUMN `vote_permission` VARCHAR(50) DEFAULT 'all';");
    mysqli_query($connection, "ALTER TABLE posts ADD COLUMN `video_path` VARCHAR(255);");
    mysqli_query($connection, "ALTER TABLE posts CHANGE COLUMN `image_url` `video_image_url` Text;");
    mysqli_query($connection, "ALTER TABLE posts CHANGE COLUMN `embed_code` `video_embed_code` Text;");
    mysqli_query($connection, "ALTER TABLE posts ADD COLUMN `status` INT DEFAULT 1;");
    mysqli_query($connection, "ALTER TABLE posts ADD COLUMN `feed_id` INT;");
    mysqli_query($connection, "ALTER TABLE posts ADD COLUMN `post_url` VARCHAR(1000);");
    mysqli_query($connection, $sql_2);
    mysqli_query($connection, "ALTER TABLE settings DROP COLUMN `site_description`;");
    mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `home_title` VARCHAR(255) DEFAULT 'Home';");
    mysqli_query($connection, "ALTER TABLE settings DROP COLUMN `show_videos_homepage`;");
    mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `head_code` Text;");


    /* close connection */
    mysqli_close($connection);

    $_SESSION["success"] = "Update completed successfully! Please delete update folder.";
    header("Location: database.php");
    exit();

}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Varient - Installer</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font-awesome CSS -->
    <link href="../assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-sm-12 col-md-offset-2">

            <div class="row">
                <div class="col-sm-12 logo-cnt">
                    <p>
                        <img src="assets/img/logo.png" alt="">
                    </p>
                    <h1>Welcome to the Installer</h1>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">

                    <div class="install-box">


                        <div class="steps">
                            <div class="step-progress">
                                <div class="step-progress-line" data-now-value="100" data-number-of-steps="3" style="width: 100%;"></div>
                            </div>
                            <div class="step">
                                <div class="step-icon"><i class="fa fa-code"></i></div>
                                <p>Start</p>
                            </div>
                            <div class="step active">
                                <div class="step-icon"><i class="fa fa-database"></i></div>
                                <p>Database</p>
                            </div>
                        </div>

                        <div class="messages">
                            <?php if (isset($_SESSION["success"])): ?>
                                <div class="alert alert-success">
                                    <strong><?php echo $_SESSION["success"]; ?></strong>
                                </div>
                            <?php elseif (isset($_SESSION["error"])): ?>
                                <div class="alert alert-danger">
                                    <strong><?php echo $_SESSION["error"]; ?></strong>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="step-contents">
                            <div class="tab-1">
                                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                                    <div class="tab-content">
                                        <div class="tab_1">
                                            <h1 class="step-title">Database</h1>
                                            <div class="form-group">
                                                <label for="email">Host</label>
                                                <input type="text" class="form-control form-input" name="db_host" placeholder="Host"
                                                       value="<?php echo isset($_SESSION["db_host"]) ? $_SESSION["db_host"] : 'localhost'; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Database Name</label>
                                                <input type="text" class="form-control form-input" name="db_name" placeholder="Database Name" value="<?php echo @$_SESSION["db_name"]; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Username</label>
                                                <input type="text" class="form-control form-input" name="db_user" placeholder="Username" value="<?php echo @$_SESSION["db_user"]; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Password</label>
                                                <input type="password" class="form-control form-input" name="db_password" placeholder="Password" value="<?php echo @$_SESSION["db_password"]; ?>">
                                            </div>

                                        </div>
                                    </div>

                                    <div class="buttons">
                                        <a href="index.php" class="btn btn-success btn-custom pull-left">Prev</a>
                                        <button type="submit" name="btn_update" class="btn btn-success btn-custom pull-right">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>


        </div>


    </div>


</div>


<?php

unset($_SESSION["error"]);
unset($_SESSION["success"]);

?>

</body>
</html>

