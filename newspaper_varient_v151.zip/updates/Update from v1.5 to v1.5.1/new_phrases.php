<?php

$lang["confirm_user_email"] = "Confirm User Email";