<?php
session_start();

if (!isset($_SESSION["purchase_code"])) {
    $_SESSION["error"] = "Invalid purchase code!";
    header("Location: index.php");
    exit();
}

$license_code = $_SESSION["license_code"];
$purchase_code = $_SESSION["purchase_code"];

if (isset($_POST["btn_update"])) {

    $_SESSION["db_host"] = $_POST['db_host'];
    $_SESSION["db_name"] = $_POST['db_name'];
    $_SESSION["db_user"] = $_POST['db_user'];
    $_SESSION["db_password"] = $_POST['db_password'];

    /* Database Credentials */
    defined("DB_HOST") ? null : define("DB_HOST", $_POST['db_host']);
    defined("DB_USER") ? null : define("DB_USER", $_POST['db_user']);
    defined("DB_PASS") ? null : define("DB_PASS", $_POST['db_password']);
    defined("DB_NAME") ? null : define("DB_NAME", $_POST['db_name']);

    /* Connect */
    $connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if (!$connection) {
        $_SESSION["error"] = "Connect failed! Please check your database credentials.";
    } else {

        $connection->query("SET CHARACTER SET utf8");
        $connection->query("SET NAMES utf8");

        $sql_reactions = "CREATE TABLE `reactions` (
        `id` INT AUTO_INCREMENT PRIMARY KEY, 
        `post_id` INT,
        `re_like` INT DEFAULT 0,
        `re_dislike` INT DEFAULT 0,
        `re_love` INT DEFAULT 0,
        `re_funny` INT DEFAULT 0,
        `re_angry` INT DEFAULT 0,
        `re_sad` INT DEFAULT 0,
        `re_wow` INT DEFAULT 0
        )ENGINE=InnoDB DEFAULT CHARSET=utf8;";

        /* update database */
        mysqli_query($connection, $sql_reactions);
        sleep(1);
        mysqli_query($connection, "ALTER TABLE posts ADD COLUMN `show_right_column` INT DEFAULT 1;");
        mysqli_query($connection, "ALTER TABLE posts CHANGE COLUMN `video_image_url` `image_url` TEXT;");
        sleep(1);
        mysqli_query($connection, "ALTER TABLE general_settings ADD COLUMN `emoji_reactions` INT DEFAULT 1;");
        mysqli_query($connection, "ALTER TABLE general_settings ADD COLUMN `newsletter` INT DEFAULT 1;");
        sleep(2);


        /* close connection */
        mysqli_close($connection);

        $_SESSION["success"] = "Update completed successfully! Please delete update folder.";
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Varient - Update Wizard</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,700" rel="stylesheet">
    <!-- Font-awesome CSS -->
    <link href="../assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-sm-12 col-md-offset-2">

            <div class="row">
                <div class="col-sm-12 logo-cnt">
                    <p>
                        <img src="assets/img/logo.png" alt="">
                    </p>
                    <h1>Welcome to the Update Wizard</h1>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">

                    <div class="install-box">


                        <div class="steps">
                            <div class="step-progress">
                                <div class="step-progress-line" data-now-value="100" data-number-of-steps="3" style="width: 100%;"></div>
                            </div>
                            <div class="step">
                                <div class="step-icon"><i class="fa fa-code"></i></div>
                                <p>Start</p>
                            </div>
                            <div class="step active">
                                <div class="step-icon"><i class="fa fa-database"></i></div>
                                <p>Database</p>
                            </div>
                        </div>

                        <div class="messages">
                            <?php if (isset($_SESSION["error"])) { ?>
                                <div class="alert alert-danger">
                                    <strong><?php echo $_SESSION["error"]; ?></strong>
                                </div>
                            <?php } ?>
                            <?php if (isset($_SESSION["success"])) { ?>
                                <div class="alert alert-success">
                                    <strong><?php echo $_SESSION["success"]; ?></strong>
                                </div>
                            <?php } ?>
                        </div>

                        <div class="step-contents">
                            <div class="tab-1">
                                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                                    <div class="tab-content">
                                        <div class="tab_1">
                                            <h1 class="step-title">Database</h1>
                                            <div class="form-group">
                                                <label for="email">Host</label>
                                                <input type="text" class="form-control form-input" name="db_host" placeholder="Host"
                                                       value="<?php echo isset($_SESSION["db_host"]) ? $_SESSION["db_host"] : 'localhost'; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Database Name</label>
                                                <input type="text" class="form-control form-input" name="db_name" placeholder="Database Name" value="<?php echo @$_SESSION["db_name"]; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Username</label>
                                                <input type="text" class="form-control form-input" name="db_user" placeholder="Username" value="<?php echo @$_SESSION["db_user"]; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Password</label>
                                                <input type="password" class="form-control form-input" name="db_password" placeholder="Password" value="<?php echo @$_SESSION["db_password"]; ?>">
                                            </div>

                                        </div>
                                    </div>

                                    <div class="buttons">
                                        <a href="index.php" class="btn btn-success btn-custom pull-left">Prev</a>
                                        <button type="submit" name="btn_update" class="btn btn-success btn-custom pull-right">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>


        </div>


    </div>


</div>

<?php

unset($_SESSION["error"]);
unset($_SESSION["success"]);

?>

</body>
</html>

