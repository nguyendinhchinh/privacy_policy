<?php
session_start();

if (!isset($_SESSION["purchase_code"])) {
    $_SESSION["error"] = "Invalid purchase code!";
    header("Location: index.php");
    exit();
}

$license_code = $_SESSION["license_code"];
$purchase_code = $_SESSION["purchase_code"];

if (isset($_POST["btn_update"])) {

    $_SESSION["db_host"] = $_POST['db_host'];
    $_SESSION["db_name"] = $_POST['db_name'];
    $_SESSION["db_user"] = $_POST['db_user'];
    $_SESSION["db_password"] = $_POST['db_password'];

    /* Database Credentials */
    defined("DB_HOST") ? null : define("DB_HOST", $_POST['db_host']);
    defined("DB_USER") ? null : define("DB_USER", $_POST['db_user']);
    defined("DB_PASS") ? null : define("DB_PASS", $_POST['db_password']);
    defined("DB_NAME") ? null : define("DB_NAME", $_POST['db_name']);

    /* Connect */
    $connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

    if (!$connection) {
        $_SESSION["error"] = "Connect failed! Please check your database credentials.";
    } else {

        $connection->query("SET CHARACTER SET utf8");
        $connection->query("SET NAMES utf8");


        $sql_general_settings = "CREATE TABLE `general_settings` (
        `id` INT AUTO_INCREMENT PRIMARY KEY, 
        `site_lang` INT DEFAULT 1,
        `multilingual_system` INT DEFAULT 1,
        `site_color` VARCHAR(100) DEFAULT 'default',
        `show_hits` INT DEFAULT 1,
        `show_rss` INT DEFAULT 1,
        `show_newsticker` INT DEFAULT 1,
        `pagination_per_page` INT DEFAULT 16,
        `google_analytics` Text,
        `primary_font` VARCHAR(255),
        `secondary_font` VARCHAR(255),
        `tertiary_font` VARCHAR(255),
        `mail_protocol` VARCHAR(100) DEFAULT 'smtp',
        `mail_host` VARCHAR(255),
        `mail_port` VARCHAR(255) DEFAULT '587',
        `mail_username` VARCHAR(255),
        `mail_password` VARCHAR(255),
        `mail_title` VARCHAR(255),
        `facebook_app_id` VARCHAR(500),
        `facebook_app_secret` VARCHAR(500),
        `google_app_name` VARCHAR(500),
        `google_client_id` VARCHAR(500),
        `google_client_secret` VARCHAR(500),
        `facebook_comment` Text,
        `facebook_comment_active` INT DEFAULT 1,
        `show_featured_section` INT DEFAULT 1,
        `show_latest_posts` INT DEFAULT 1,
        `registration_system` INT DEFAULT 1,
        `comment_system` INT DEFAULT 1,
        `show_post_author` INT DEFAULT 1,
        `show_post_date` INT DEFAULT 1,
        `menu_limit` INT DEFAULT 8,
        `copyright` VARCHAR(500),
        `head_code` Text,
        `vr_key` VARCHAR(500),
        `purchase_code` VARCHAR(255),
        `recaptcha_site_key` VARCHAR(255),
        `recaptcha_secret_key` VARCHAR(255),
        `recaptcha_lang` VARCHAR(50),
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP
        )ENGINE=InnoDB DEFAULT CHARSET=utf8;";


        $sql_settings = "CREATE TABLE `settings` (
        `id` INT AUTO_INCREMENT PRIMARY KEY, 
        `lang_id` INT DEFAULT 1,
        `site_title` VARCHAR(255),
        `home_title` VARCHAR(255),
        `site_description` VARCHAR(500),
        `keywords` VARCHAR(500),
        `application_name` VARCHAR(255),
        `facebook_url` VARCHAR(500),
        `twitter_url` VARCHAR(500),
        `google_url` VARCHAR(500),
        `instagram_url` VARCHAR(500),
        `pinterest_url` VARCHAR(500),
        `linkedin_url` VARCHAR(500),
        `vk_url` VARCHAR(500),
        `youtube_url` VARCHAR(500),
        `optional_url_button_name` VARCHAR(500) DEFAULT 'Click',
        `about_footer` VARCHAR(1000),
        `contact_text` Text,
        `contact_address` VARCHAR(500),
        `contact_email` VARCHAR(255),
        `contact_phone` VARCHAR(255),
        `map_api_key` VARCHAR(500),
        `latitude` VARCHAR(255),
        `longitude` VARCHAR(255),
        `copyright` VARCHAR(500),
        `cookies_warning` INT DEFAULT 1,
        `cookies_warning_text` Text,
        `created_at` timestamp DEFAULT CURRENT_TIMESTAMP
        )ENGINE=InnoDB DEFAULT CHARSET=utf8;";


        $sql_images = "CREATE TABLE `images` (
        `id` INT AUTO_INCREMENT PRIMARY KEY, 
        `lang_id` INT DEFAULT 1,
        `image_big` VARCHAR(255),
        `image_default` VARCHAR(255),
        `image_slider` VARCHAR(255),
        `image_mid` VARCHAR(255),
         `image_small` VARCHAR(255)
        )ENGINE=InnoDB DEFAULT CHARSET=utf8;";

        $sql_languages = "CREATE TABLE `languages` (
        `id` INT AUTO_INCREMENT PRIMARY KEY, 
        `name` VARCHAR(255),
        `short_form` VARCHAR(255),
        `language_code` VARCHAR(100),
        `folder_name` VARCHAR(255),
        `text_direction` VARCHAR(50),
        `status` INT DEFAULT 1,
        `language_order` INT DEFAULT 1
        )ENGINE=InnoDB DEFAULT CHARSET=utf8;";

        $sql_post_audios = "CREATE TABLE `post_audios` (
        `id` INT AUTO_INCREMENT PRIMARY KEY, 
        `post_id` INT,
        `audio_id` INT
        )ENGINE=InnoDB DEFAULT CHARSET=utf8;";

        $sql_videos = "CREATE TABLE `videos` (
        `id` INT AUTO_INCREMENT PRIMARY KEY, 
        `video_name` VARCHAR(255),
        `video_path` VARCHAR(255)
        )ENGINE=InnoDB DEFAULT CHARSET=utf8;";


        /* update database */
        mysqli_query($connection, "DROP TABLE settings;");
        mysqli_query($connection, $sql_general_settings);
        sleep(1);
        mysqli_query($connection, $sql_settings);

        mysqli_query($connection, $sql_images);
        mysqli_query($connection, $sql_languages);
        mysqli_query($connection, $sql_post_audios);
        sleep(1);
        mysqli_query($connection, $sql_videos);
        mysqli_query($connection, "ALTER TABLE categories ADD COLUMN `lang_id` INT DEFAULT 1;");
        mysqli_query($connection, "ALTER TABLE gallery ADD COLUMN `lang_id` INT DEFAULT 1;");
        mysqli_query($connection, "ALTER TABLE gallery_categories ADD COLUMN `lang_id` INT DEFAULT 1;");
        mysqli_query($connection, "ALTER TABLE pages ADD COLUMN `lang_id` INT DEFAULT 1;");
        mysqli_query($connection, "ALTER TABLE polls ADD COLUMN `lang_id` INT DEFAULT 1;");
        mysqli_query($connection, "ALTER TABLE posts ADD COLUMN `lang_id` INT DEFAULT 1;");
        mysqli_query($connection, "ALTER TABLE posts ADD COLUMN `image_description` VARCHAR(500);");
        mysqli_query($connection, "ALTER TABLE rss_feeds ADD COLUMN `lang_id` INT DEFAULT 1;");
        mysqli_query($connection, "ALTER TABLE widgets ADD COLUMN `lang_id` INT DEFAULT 1;");
        mysqli_query($connection, "DELETE FROM pages WHERE slug='index';");
        mysqli_query($connection, "ALTER TABLE posts ADD COLUMN `show_post_url` INT DEFAULT 1;");
        mysqli_query($connection, "UPDATE pages SET slug='rss-feeds' WHERE slug='rss-channels';");

        sleep(1);

        mysqli_query($connection, "INSERT INTO `general_settings` (`site_lang`, `multilingual_system`, `site_color`, `show_hits`, `show_rss`, `show_newsticker`, `pagination_per_page`, `google_analytics`, `primary_font`, `secondary_font`, `tertiary_font`, `mail_protocol`, `mail_host`, `mail_port`, `mail_username`, `mail_password`, `mail_title`, `facebook_app_id`, `facebook_app_secret`, `google_app_name`, `google_client_id`, `google_client_secret`, `facebook_comment`, `facebook_comment_active`, `show_featured_section`, `show_latest_posts`, `registration_system`, `comment_system`, `show_post_author`, `show_post_date`, `menu_limit`, `copyright`, `head_code`, `vr_key`, `purchase_code`, `recaptcha_site_key`, `recaptcha_secret_key`, `recaptcha_lang`) VALUES
        (1, 1, 'default', 1, 1, 1, 16, '', 'open_sans', 'roboto', 'verdana', 'smtp', '', '', '', '', '', '', '', 'Varient', '', '', '', 1, 1, 1, 1, 1, 1, 1, 8, 'Copyright © 2018 Varient - All Rights Reserved.', '', '" . $license_code . "', '" . $purchase_code . "', '', '', 'en')");

        mysqli_query($connection, "INSERT INTO `settings` (`id`, `lang_id`, `site_title`, `home_title`, `site_description`, `keywords`, `application_name`, `facebook_url`, `twitter_url`, `google_url`, `instagram_url`, `pinterest_url`, `linkedin_url`, `vk_url`, `youtube_url`, `optional_url_button_name`, `about_footer`, `contact_text`, `contact_address`, `contact_email`, `contact_phone`, `map_api_key`, `latitude`, `longitude`, `copyright`, `cookies_warning`, `cookies_warning_text`) VALUES
(1, 1, 'Varient - News Magazine', 'Index', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Click Here To See More', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Copyright © 2018 Varient - All Rights Reserved.', 1, '<p>This site uses cookies. By continuing to browse the site you are agreeing to our use of cookies</p>\r\n');");

        mysqli_query($connection, "INSERT INTO `widgets` (`lang_id`, `title`, `type`, `widget_order`, `visibility`, `is_custom`) VALUES (1, 'Follow Us', 'follow-us', 1, 1, 0);");
        mysqli_query($connection, "INSERT INTO `languages` (`name`, `short_form`, `language_code`, `folder_name`, `text_direction`, `status`, `language_order`) VALUES ('English', 'en', 'en_us', 'default', 'ltr', 1, 1);");
        sleep(1);

        //add images to images table
        $sql = "SELECT * FROM posts ORDER BY id";
        $result = mysqli_query($connection, $sql);
        while ($row = mysqli_fetch_array($result)) {

            if (!empty($row['image_mid'])) {
                $insert = "INSERT INTO images (lang_id, image_big, image_default, image_slider, image_mid, image_small) VALUES (1, '" . $row['image_big'] . "', '" . $row['image_default'] . "', '" . $row['image_slider'] . "', '" . $row['image_mid'] . "', '" . $row['image_small'] . "')";
                mysqli_query($connection, $insert);
            }

        }
        sleep(1);
        //add videos to videos table
        $i = 1;
        $sql = "SELECT * FROM posts ORDER BY id";
        $result = mysqli_query($connection, $sql);
        while ($row = mysqli_fetch_array($result)) {

            if (!empty($row['video_path'])) {
                $insert = "INSERT INTO videos (video_name, video_path) VALUES ('video-" . $i . "', '" . $row['video_path'] . "')";
                mysqli_query($connection, $insert);
            }

            $i++;
        }
        sleep(1);
        //add audios to post_audios table
        $sql = "SELECT * FROM audios ORDER BY id";
        $result = mysqli_query($connection, $sql);
        while ($row = mysqli_fetch_array($result)) {

            if (!empty($row['post_id'])) {
                $insert = "INSERT INTO post_audios (post_id, audio_id) VALUES ('" . $row['post_id'] . "', '" . $row['id'] . "')";
                mysqli_query($connection, $insert);
            }

        }

        mysqli_query($connection, "ALTER TABLE audios DROP COLUMN `post_id`;");
        sleep(2);
        /* close connection */
        mysqli_close($connection);

        $_SESSION["success"] = "Update completed successfully! Please delete update folder.";
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Varient - Update Wizard</title>

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,700" rel="stylesheet">
    <!-- Font-awesome CSS -->
    <link href="../assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-sm-12 col-md-offset-2">

            <div class="row">
                <div class="col-sm-12 logo-cnt">
                    <p>
                        <img src="assets/img/logo.png" alt="">
                    </p>
                    <h1>Welcome to the Update Wizard</h1>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">

                    <div class="install-box">


                        <div class="steps">
                            <div class="step-progress">
                                <div class="step-progress-line" data-now-value="100" data-number-of-steps="3" style="width: 100%;"></div>
                            </div>
                            <div class="step">
                                <div class="step-icon"><i class="fa fa-code"></i></div>
                                <p>Start</p>
                            </div>
                            <div class="step active">
                                <div class="step-icon"><i class="fa fa-database"></i></div>
                                <p>Database</p>
                            </div>
                        </div>

                        <div class="messages">
                            <?php if (isset($_SESSION["error"])) { ?>
                                <div class="alert alert-danger">
                                    <strong><?php echo $_SESSION["error"]; ?></strong>
                                </div>
                            <?php } ?>
                            <?php if (isset($_SESSION["success"])) { ?>
                                <div class="alert alert-success">
                                    <strong><?php echo $_SESSION["success"]; ?></strong>
                                </div>
                            <?php } ?>
                        </div>

                        <div class="step-contents">
                            <div class="tab-1">
                                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                                    <div class="tab-content">
                                        <div class="tab_1">
                                            <h1 class="step-title">Database</h1>
                                            <div class="form-group">
                                                <label for="email">Host</label>
                                                <input type="text" class="form-control form-input" name="db_host" placeholder="Host"
                                                       value="<?php echo isset($_SESSION["db_host"]) ? $_SESSION["db_host"] : 'localhost'; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Database Name</label>
                                                <input type="text" class="form-control form-input" name="db_name" placeholder="Database Name" value="<?php echo @$_SESSION["db_name"]; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Username</label>
                                                <input type="text" class="form-control form-input" name="db_user" placeholder="Username" value="<?php echo @$_SESSION["db_user"]; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Password</label>
                                                <input type="password" class="form-control form-input" name="db_password" placeholder="Password" value="<?php echo @$_SESSION["db_password"]; ?>">
                                            </div>

                                        </div>
                                    </div>

                                    <div class="buttons">
                                        <a href="index.php" class="btn btn-success btn-custom pull-left">Prev</a>
                                        <button type="submit" name="btn_update" class="btn btn-success btn-custom pull-right">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>


                    </div>
                </div>
            </div>


        </div>


    </div>


</div>

<?php

unset($_SESSION["error"]);
unset($_SESSION["success"]);

?>

</body>
</html>

