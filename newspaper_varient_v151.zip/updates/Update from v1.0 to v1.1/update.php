<?php
session_start();

/* Database Credentials */
defined("DB_HOST") ? null : define("DB_HOST", "your host");
defined("DB_USER") ? null : define("DB_USER", "your db user");
defined("DB_PASS") ? null : define("DB_PASS", "your db pass");
defined("DB_NAME") ? null : define("DB_NAME", "your db name");




/* Connect */
$connection = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
$connection->query("SET CHARACTER SET utf8");
$connection->query("SET NAMES utf8");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed! Please check your database credentials.");
    exit();
}else{
  /* update database */
  mysqli_query($connection, "ALTER TABLE categories ADD COLUMN `show_at_homepage` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE categories ADD COLUMN `show_on_menu` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `facebook_comment` TEXT;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `facebook_comment_active` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `show_featured_section` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `show_latest_posts` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `show_videos_homepage` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `registration_system` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `comment_system` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `show_post_author` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `show_post_date` INT DEFAULT 1;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `menu_limit` INT DEFAULT 8;");
  mysqli_query($connection, "ALTER TABLE settings ADD COLUMN `copyright` VARCHAR(500);");
  mysqli_query($connection, "UPDATE pages SET location = 'main' WHERE id=1;");
  mysqli_query($connection, "UPDATE pages SET title = 'Home' WHERE id=1;");

  /* close connection */
  mysqli_close($connection);

  printf("Update completed successfully! Please delete update.php file.");
  exit();
}
